const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

const Event = require('../models/event');

router.get("/events", async (request, response) => {
    const users = await Event
    .find({});
  
    try {
      response.send(users);
    } catch (error) {
      response.status(500).send(error);
    }
  });

router.post('/', ( req, res, next) => {
    const event = { 
        _id: new mongoose.Types.ObjectId(),
    Category: req.body.Category,
    eventname:req.body.eventname,
    artist: req.body.artist,
    data: req.body.data,
    city: req.body.city,
    place: req.body.place,
    Address: req.body.Address,
    time: req.body.time,
    price: req.body.price,
    tickets: req.body.tickets,
    Image: req.body.Image
       };
       res.status(201).json({
        message: 'Handling post req',
        createdEvent: event
       });
});

router.get("/", (req, res, next) => {
    Event.find()
    .then(docs => {
        console.log(docs);
        res.status(200).json(docs); 
    })
        
    .catch(err => {
        console.log(err);
        res.status(500).json({error: err});
    });
});


  router.get("/:eventId", (req, res, next) => {
    const id = req.params.eventId;
    Event.findById(id)
    .exec()
    .then(doc => {
        console.log(doc);
        if(doc) {
            res.status(200).json(doc); 
        } else {
            res.status(404).json({message: ' Not valid entry for id'})
        }
       
    })
    .catch(err => {
        res.status(500).json({error: err});
        });
});  

module.exports = router;
